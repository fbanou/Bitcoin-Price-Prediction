import matplotlib.pyplot as plt
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping

def build_model(input_shape):
    """
    Build and return a Sequential LSTM model for time series forecasting.
    The model consists of two LSTM layers with dropout and two Dense layers.
    """
    model = Sequential([
        LSTM(128, return_sequences=True, input_shape=input_shape),
        Dropout(0.4),
        LSTM(64, return_sequences=False),
        Dropout(0.4),
        Dense(64, activation='relu'),
        Dense(1)  # Single output for predicting 'close'
    ])
    return model

def compile_and_train_model(model, X_train, y_train, learning_rate=0.001, batch_size=256, epochs=50, validation_split=0.2, patience=15):
    """
    Compile the model with Adam optimizer and MSE loss, then train it using early stopping.
    """
    early_stopping = EarlyStopping(monitor='val_loss', patience=patience, restore_best_weights=True)
    model.compile(optimizer=Adam(learning_rate=learning_rate),
                  loss='mean_squared_error',
                  metrics=['mean_absolute_error'])
    history = model.fit(X_train, y_train, batch_size=batch_size, epochs=epochs,
                        validation_split=validation_split, verbose=1,
                        callbacks=[early_stopping], shuffle=False)
    return history
