from data_loader import  load_data, resample_data, split_data, scale_dataset, create_dataset
from model_training import train_model_custom
from inference import predict_and_evaluate_model, run_multiple_experiments1
import pandas as pd

def main():

    # Define file path and parameters
    file_path = '../../bitcoin-dataset.csv'
    sampling_time = 1  # 0: minute, 1: hourly, 2: daily, 3: monthly
    window_size = 24

    # Load data and resample
    data = load_data(file_path)
    data_resampled = resample_data(data, sampling_time)

    # Define split dates
    train_end_date = '2022-02-18 23:59:59'
    test_start_date = '2022-02-19 00:00:00'
    test_end_date = '2022-02-28 23:59:59'
    train_data, test_data = split_data(data_resampled, train_end_date, test_start_date, test_end_date)

    # Get last training close value scaled to reconstruct forecast
    last_close_value = train_data['close'].iloc[-1]

    # For this code, we use differences of the 'close' values from the training set
    train_diff = train_data['close'].diff().dropna()
    train_diff = pd.DataFrame(train_diff, index=train_diff.index, columns=['close'])

    # Scale the datasets
    train_scaled, scaler = scale_dataset(train_diff)

    # Create training dataset windows
    X_train, y_train = create_dataset(train_scaled, window_size, len(test_data))
    print(f"Shape of X_train: {X_train.shape}")
    print(f"Shape of y_train: {y_train.shape}")

    # Test targets from the test set remain as is
    y_test = test_data.iloc[:, 0].values

    # ---- Single Experiment ----
    print("\nRunning Single Experiment...")
    num_features = X_train.shape[2]
    model, history = train_model_custom(X_train, y_train)
    predict_and_evaluate_model(model, X_train, y_test, scaler, history, last_close_value)

    # ---- Multiple Experiments ----
    print("\nRunning Multiple Experiments (10 runs)...")
    run_multiple_experiments1(10, X_train, y_train, y_test, scaler, last_close_value)


if __name__ == "__main__":
    main()
