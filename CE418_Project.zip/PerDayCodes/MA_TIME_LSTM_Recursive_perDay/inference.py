import numpy as np
import time
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error

def predict_test(model, train_scaled, test_scaled, sequence_length, feature_columns, scaler, test_data):
    """
    Generate predictions for the test set using an iterative approach.
    The input sequence is updated with the predicted value and new moving averages are computed.
    """
    # Remove 'MA_5', 'MA_24', and 'close' from test_scaled to retain only time features
    test_scaled_filtered = np.delete(test_scaled, [0, 1, -1], axis=1)

    # Get the last 24 scaled 'close' values from training data last column
    last_close_values = train_scaled[-24:, -1].tolist()

    # Initialize the input sequence with the last sequence_length entries excluding 'close'
    input_sequence = train_scaled[-sequence_length:, :-1].tolist()

    predictions = []

    # Iteratively predict each time step in the test set
    for i in range(len(test_scaled_filtered)):
        # Prepare the input sequence for prediction
        x_input = np.array(input_sequence).reshape(1, sequence_length, len(feature_columns))
        # Predict the next scaled close value
        predicted_value_scaled = model.predict(x_input, verbose=0)[0, 0]
        predictions.append(predicted_value_scaled)

        # Update the close values list with the new prediction
        last_close_values.append(predicted_value_scaled)
        last_close_values.pop(0)

        # Compute moving averages from the updated close values
        ma_5 = np.mean(last_close_values[-5:])
        ma_24 = np.mean(last_close_values[-24:])

        # Retrieve the already scaled time features for the current test time step
        time_features_scaled = test_scaled_filtered[i]

        # Create the new input feature vector with updated moving averages and time features
        next_input_scaled = np.concatenate([[ma_5, ma_24], time_features_scaled])

        # Update the input sequence window for the next prediction
        input_sequence.append(next_input_scaled)
        input_sequence.pop(0)

    # Inverse transform the predictions to obtain the original scale
    predicted_close_unscaled = scaler.inverse_transform(
        np.concatenate([test_scaled[:, :-1], np.array(predictions).reshape(-1, 1)], axis=1)
    )[:, -1]

    return predicted_close_unscaled, predictions

def plot_training_history(history):
    """
    Plot the training and validation loss over epochs.
    """
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.title('Loss vs Validation Loss')
    plt.show()

def plot_predictions(test_data, actual_close, predicted_close_unscaled):
    """
    Plot the actual vs predicted close prices.
    """
    plt.figure(figsize=(12, 6))
    plt.plot(test_data.index, actual_close, label="Actual Close", color='blue', linestyle='dashed')
    plt.plot(test_data.index, predicted_close_unscaled, label="Predicted Close", color='red')
    plt.xlabel("Date")
    plt.ylabel("Close Price")
    plt.title("Comparison of Actual vs Predicted Close Prices")
    plt.legend()
    plt.grid(True)
    plt.show()

def evaluate_predictions(actual_close, predicted_close_unscaled):
    """
    Evaluate the predictions using common regression metrics.
    """
    mae = mean_absolute_error(actual_close, predicted_close_unscaled)
    mse = mean_squared_error(actual_close, predicted_close_unscaled)
    rmse = np.sqrt(mse)

    print("Mean Absolute Error (MAE):", mae)
    print("Mean Squared Error (MSE):", mse)
    print("Root Mean Squared Error (RMSE):", rmse)


def run_multiple_experiments(x_train, y_train, train_scaled, test_scaled, sequence_length,
                             feature_columns, scaler, test_data, num_runs=10):
    """
    Runs the training, prediction, and evaluation process num_runs times,
    then computes and plots the average training/validation loss curves and
    the average predicted close price against the actual values.
    """
    training_histories = []  # To store the training history for each run
    predicted_runs = []      # To store the predicted close values for each run
    metrics_list = []        # To store the evaluation metrics for each run
    train_times = []         # To store execution times for model training
    predict_times = []      # To store execution times for predict

    # Get actual close values from the test data once
    actual_close = test_data['close'].values

    for run in range(num_runs):
        print(f"Run {run+1}/{num_runs}")
        from model_training import build_lstm_model, train_model
        # Build the LSTM model
        model = build_lstm_model(sequence_length, len(feature_columns))
        # Train the model
        start_time = time.time()
        history = train_model(model, x_train, y_train)
        train_time = time.time() - start_time
        train_times.append(train_time)

        training_histories.append(history)
        # Generate predictions for the test set
        start_time = time.time()
        predicted_close_unscaled, _ = predict_test(model, train_scaled, test_scaled,
                                                   sequence_length, feature_columns, scaler, test_data)
        predict_time = time.time() - start_time
        predict_times.append(predict_time)

        predicted_runs.append(predicted_close_unscaled)
        # Calculate evaluation metrics
        mae = mean_absolute_error(actual_close, predicted_close_unscaled)
        mse = mean_squared_error(actual_close, predicted_close_unscaled)
        rmse = np.sqrt(mse)
        metrics_list.append({'MAE': mae, 'MSE': mse, 'RMSE': rmse})

    # Determine the minimum number of epochs among all runs due to early stopping, these may vary
    min_epochs = min(len(hist.history['loss']) for hist in training_histories if 'loss' in hist.history)
    # Average the training and validation loss curves over the minimum number of epochs
    avg_loss = np.mean([hist.history['loss'][:min_epochs] for hist in training_histories if 'loss' in hist.history], axis=0)
    avg_val_loss = np.mean([hist.history['val_loss'][:min_epochs] for hist in training_histories if 'val_loss' in hist.history], axis=0)

    # Plot the average training history
    plt.figure(figsize=(8, 5))
    epochs_range = range(1, min_epochs+1)
    plt.plot(epochs_range, avg_loss, label='Average Training Loss')
    plt.plot(epochs_range, avg_val_loss, label='Average Validation Loss')
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title(f"Average Training & Validation Loss over {num_runs} Runs")
    plt.legend()
    plt.grid(True)
    plt.show()

    # Compute the average predicted close prices across runs
    avg_predicted_close = np.mean(np.array(predicted_runs), axis=0)

    # Plot the actual close vs. average predicted close
    plot_predictions(test_data, actual_close, avg_predicted_close)

    # Average the evaluation metrics over all runs
    avg_metrics = {
         'MAE': np.mean([m['MAE'] for m in metrics_list]),
         'MSE': np.mean([m['MSE'] for m in metrics_list]),
         'RMSE': np.mean([m['RMSE'] for m in metrics_list])
    }
    print(f"Average Metrics over {num_runs} Runs:")
    print("Mean Absolute Error (MAE):", avg_metrics['MAE'])
    print("Mean Squared Error (MSE):", avg_metrics['MSE'])
    print("Root Mean Squared Error (RMSE):", avg_metrics['RMSE'])

    # Compute and print average execution times
    avg_train_time = np.mean(train_times)
    avg_predict_time = np.mean(predict_times)
    print(f"\nAverage Execution Times over {num_runs} Runs:")
    print(f"Model Training Time: {avg_train_time:.4f} seconds")
    print(f"Predicting Time: {avg_predict_time:.4f} seconds")
