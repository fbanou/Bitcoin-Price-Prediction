import pandas as pd
import numpy as np
from data_loader import load_data, resample_data, scale_and_split_data, create_dataset
from model_training import train_model
from inference import plot_loss, predict_and_evaluate_model, run_multiple_experiments

def main():
    file_path = '../../bitcoin-dataset.csv'

    data = load_data(file_path)
    data_resampled = resample_data(data, time=1)
    train_scaled, test_scaled, scaler = scale_and_split_data(data_resampled, '2022-02-18 23:59:59', '2022-02-19 00:00:00', '2022-02-28 23:59:59')

    window_size = 60
    forecast_horizon = len(test_scaled)

    X_train, y_train = create_dataset(train_scaled, window_size, forecast_horizon)
    X_test = train_scaled['close'].iloc[-window_size:].values
    y_test = test_scaled.iloc[:, 0].values
    dates = test_scaled.index[-len(y_test):]  # Dates for plotting

    print("\nRunning Single Experiment...")
    model, history = train_model(X_train, y_train, epochs=100, patience=15, batch_size=256, forecast_horizon=forecast_horizon)
    plot_loss(history)
    predict_and_evaluate_model(model, X_test, y_test, scaler, dates)

    print("\nRunning Multiple Experiments...")
    run_multiple_experiments(10, X_train, y_train, X_test, y_test, dates, scaler, 256, forecast_horizon)

if __name__ == "__main__":
    main()
