import pandas as pd
import numpy as np
from data_loader import preprocess_data, add_seasonal_stats_from_train, scale_data, create_windows
from model_training import build_model, compile_and_train_model
from inference import predict_and_evaluate, plot_loss, run_multiple_experiments

def main():

    # Define the file path for the dataset
    file_path = "../../bitcoin-dataset.csv"

    data_hourly = preprocess_data(file_path)

    # Define train/test date ranges
    train_end_date = '2022-02-18 23:59:59'
    test_start_date = '2022-02-19 00:00:00'
    test_end_date = '2022-02-28 23:59:59'

    # Split the data into training and testing sets
    train_data = data_hourly[:train_end_date]
    test_data = data_hourly[test_start_date:test_end_date]

    # Add seasonal statistics based only on the training set for 'hour', 'weekday', and 'month'
    data_hourly = add_seasonal_stats_from_train(data_hourly, train_data, 'hour', 'close')
    data_hourly = add_seasonal_stats_from_train(data_hourly, train_data, 'weekday', 'close')
    data_hourly = add_seasonal_stats_from_train(data_hourly, train_data, 'month', 'close')

    # For further processing, select only the desired columns including seasonal stats
    data_hourly = data_hourly[['hour_mean_close', 'weekday_mean_close', 'month_mean_close',
                               'hour_sin', 'hour_cos', 'weekday_sin', 'weekday_cos',
                               'month_sin', 'month_cos', 'year', 'is_weekend', 'close']].dropna()

    # Re-split the data into training and testing sets using the updated dataframe
    train_data = data_hourly[:train_end_date]
    test_data = data_hourly[test_start_date:test_end_date]

    # Scale the data, fit on train and transform test
    train_scaled, test_scaled, scaler = scale_data(train_data, test_data)

    # Create sliding windows
    window_size = 72
    target_column_index = data_hourly.columns.get_loc('close')

    X_train, y_train = create_windows(train_scaled.values, window_size, target_column_index)

    # For the test set, we combine the scaled train and test sets to create windows that cover the test period
    combined_data = pd.concat([train_scaled, test_scaled])
    X_test, y_test = create_windows(combined_data.values[-(len(test_scaled) + window_size):], window_size, target_column_index)

    # Print the shapes of the training and test windows
    print(f"X_train shape: {X_train.shape}")
    print(f"y_train shape: {y_train.shape}")
    print(f"X_test shape: {X_test.shape}")
    print(f"y_test shape: {y_test.shape}")
    
    # Build the LSTM model
    input_shape = (X_train.shape[1], X_train.shape[2])
    model = build_model(input_shape)
    model.summary()

    # Train the model
    print("\nRunning Single Experiment...")
    history = compile_and_train_model(model, X_train, y_train)

    # Plot the training and validation loss curves
    plot_loss(history)

    # Evaluate the model on the test set and plot the predictions
    predict_and_evaluate(model, X_test, y_test, scaler, data_hourly.columns, 'close', test_start_date, test_end_date)

    # --- Run the entire experiment multiple times (10 runs) ---
    print("\nRunning multiple experiments...")
    run_multiple_experiments(num_runs=10, X_train=X_train, y_train=y_train, X_test=X_test, y_test=y_test,
                             scaler=scaler, data_columns=data_hourly.columns, target_column='close',
                             test_start_date=test_start_date, test_end_date=test_end_date)

if __name__ == "__main__":
    main()
