from data_loader import load_and_preprocess_data, create_final_dataset, split_dataset, scale_data, create_sequences_multi_step
from model_training import  build_multi_step_model, train_model, plot_loss_history
from inference import make_forecast, plot_forecast, evaluate_forecast, run_multiple_experiments_multi_step

def main():
    
    # Define the file path for the dataset 
    file_path = "../../bitcoin-dataset.csv"

    # Load and preprocess the dataset
    data_hourly = load_and_preprocess_data(file_path)

    # Define the feature columns and target column
    feature_columns = ['MA_24', 'MA_240',
                       'hour_sin', 'hour_cos',
                       'weekday_sin', 'weekday_cos',
                       'month_sin', 'month_cos']
    target_column = 'close'

    # Create the final dataset with the selected features and target
    data_final = create_final_dataset(data_hourly, feature_columns, target_column)

    # Define date ranges for the training and testing sets
    train_end_date = '2022-02-18 23:59:59'
    test_start_date = '2022-02-19 00:00:00'
    test_end_date = '2022-02-28 23:59:59'

    # Split the data into training and testing sets
    train_data, test_data = split_dataset(data_final, train_end_date, test_start_date, test_end_date)

    # Scale the data using MinMaxScaler
    train_scaled, test_scaled, scaler = scale_data(train_data, test_data)

    # Set the sequence length and forecast horizon, forecast horizon equals the number of rows in the test set
    sequence_length = 120
    forecast_horizon = test_scaled.shape[0]

    # Create multi-step sequences from the training data
    X_train, y_train = create_sequences_multi_step(train_scaled, sequence_length, forecast_horizon)

    num_features = X_train.shape[2]

    # Build the multi-step forecasting model
    model = build_multi_step_model(sequence_length, num_features, forecast_horizon)
    model.summary()

    # Train the model
    print("\nRunning Single Experiment...")
    history = train_model(model, X_train, y_train)

    # Plot the evolution of training and validation loss
    plot_loss_history(history)

    # Make a multi-step forecast using the last available sequence from training data
    forecast_unscaled = make_forecast(model, train_scaled, sequence_length, num_features, scaler, feature_columns, forecast_horizon)

    # Plot actual vs. predicted close prices
    plot_forecast(test_data, target_column, forecast_unscaled, forecast_horizon)

    # Evaluate the forecast using regression metrics
    actual = test_data[target_column].values[:forecast_unscaled.shape[0]]
    evaluate_forecast(actual, forecast_unscaled)

    print("\nRunning multiple experiments...")
    run_multiple_experiments_multi_step(num_runs=10, X_train=X_train, y_train=y_train, train_scaled=train_scaled,
                                        sequence_length=sequence_length, num_features=num_features,
                                        scaler=scaler, feature_columns=feature_columns,
                                        forecast_horizon=forecast_horizon, test_data=test_data,
                                        target_column=target_column)


if __name__ == "__main__":
    main()
