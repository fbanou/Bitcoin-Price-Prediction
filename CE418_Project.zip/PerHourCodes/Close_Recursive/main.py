import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from data_loader import  load_and_preprocess, scale_data, split_train_test, create_dataset
from model_training import build_model, train_model
from inference import predict_and_evaluate_model,  run_multiple_experiments

def main():

    # Define the file path for the dataset
    file_path = "../../bitcoin-dataset.csv"

    # Load and preprocess data
    data_hourly = load_and_preprocess(file_path)
    data_scaled_df, scaler = scale_data(data_hourly)

    # Split data into train and test sets
    train_data, test_data, test_start_date, test_end_date = split_train_test(data_scaled_df)

    # Create sliding windows from training set
    time_step = 60
    X_train, y_train = create_dataset(train_data, time_step)
    X_train = X_train.reshape(X_train.shape[0], X_train.shape[1], X_train.shape[2])

    # For the test targets, we put the last training target to the test series
    last_y_train = y_train[-1]
    y_test = test_data.iloc[:, 0].values
    y_test = np.insert(y_test, 0, last_y_train)

    # Build and train the model
    num_features = X_train.shape[2]
    print("\nRunning Single Experiment...")
    model = build_model(time_step, num_features)
    history = train_model(model, X_train, y_train)

    # Predict and evaluate
    predict_and_evaluate_model(model, X_train, y_test, scaler, history)

    # --- Multiple Experiments ---
    print("\nRunning Multiple Experiments (10 runs)...")
    run_multiple_experiments(num_runs=10, train_data=train_data, test_data=test_data, scaler=scaler, time_step=time_step)

if __name__ == "__main__":
    main()
