import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv1D, MaxPooling1D, BatchNormalization, Dropout, LSTM, Dense
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping

def build_multi_step_model(sequence_length, num_features, forecast_horizon):
    """
    Build a Sequential model for direct multi-step forecasting.
    The model consists of convolutional layers, an LSTM block, and dense layers.
    """
    model = Sequential([
        # Convolutional Block
        Conv1D(filters=64, kernel_size=3, activation='relu', input_shape=(sequence_length, num_features)),
        BatchNormalization(),
        Conv1D(filters=64, kernel_size=3, activation='relu'),
        MaxPooling1D(pool_size=2),
        Dropout(0.5),

        # LSTM Block: Stacked LSTM layers to capture temporal dependencies
        LSTM(256, return_sequences=True, input_shape=(sequence_length, num_features)),
        BatchNormalization(),
        Dropout(0.3),
        LSTM(128, return_sequences=False),
        BatchNormalization(),
        Dropout(0.2),

        # Dense Block: Process the extracted features
        Dense(64, activation='relu'),
        Dropout(0.2),

        # Final Dense Layer to produce the multi-step forecast
        Dense(forecast_horizon, activation='linear')
    ])
    model.compile(optimizer=Adam(learning_rate=0.001),
                  loss='mean_squared_error',
                  metrics=['mean_absolute_error'])
    return model

def train_model(model, X_train, y_train, epochs=100, batch_size=256, validation_split=0.2, patience=15):
    """
    Train the model using the given training data and early stopping to prevent overfitting.
    """
    early_stopping = EarlyStopping(monitor='val_loss', patience=patience, restore_best_weights=True)
    history = model.fit(
        X_train, y_train,
        epochs=epochs,
        batch_size=batch_size,
        validation_split=validation_split,
        shuffle=False,
        callbacks=[early_stopping]
    )
    return history
