import time
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, BatchNormalization
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping

def build_lstm_model(sequence_length, num_features):
    """
    Build an optimized LSTM model for time series forecasting.
    """
    model = Sequential([
      LSTM(128, return_sequences=True, input_shape=(sequence_length, num_features)),
      BatchNormalization(),
      Dropout(0.2),
      LSTM(128, return_sequences=True),
      BatchNormalization(),
      Dropout(0.2),
      LSTM(128, return_sequences=False),
      BatchNormalization(),
      Dropout(0.2),
      Dense(64, activation='relu'),
      Dropout(0.2),
      Dense(1)
  ])

    model.compile(optimizer=Adam(learning_rate=0.001),
                  loss='mean_squared_error',
                  metrics=['mean_absolute_error'])

    return model

def train_model(model, x_train, y_train, batch_size=256, epochs=100, validation_split=0.2, patience=20):
    """
    Train the model using early stopping to prevent overfitting.
    """

    early_stopping = EarlyStopping(monitor='val_loss', patience=patience, restore_best_weights=True)

    history = model.fit(
        x_train, y_train,
        batch_size=batch_size,
        epochs=epochs,
        validation_split=validation_split,
        shuffle=False,
        callbacks=[early_stopping]
    )

    return history
