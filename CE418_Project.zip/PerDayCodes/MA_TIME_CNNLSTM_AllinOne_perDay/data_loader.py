import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

def load_and_preprocess_data(file_path):
    """
    Load the dataset from the CSV file, convert UNIX timestamps to datetime,
    set the datetime as index, and resample the data to daily frequency.
    """
    # Load dataset
    data = pd.read_csv(file_path)

    # Convert 'unix' column to datetime and set as index
    data['date'] = pd.to_datetime(data['unix'], unit='s')
    data.set_index('date', inplace=True)
    data.sort_index(ascending=True, inplace=True)

    # Use only the 'close' column
    numeric_data = data[['close']].copy()

    # Resample data to daily frequency in case the data is in minutes
    data_daily = numeric_data.resample('1d').mean()

    # Add time-based features and cyclic features
    data_daily = add_time_features(data_daily)
    data_daily = add_cyclic_features(data_daily)

    # Compute Moving Averages
    data_daily['MA_5'] = data_daily['close'].rolling(window=5).mean()
    data_daily['MA_24'] = data_daily['close'].rolling(window=24).mean()

    # Drop rows with NaN values due to rolling windows
    data_daily.dropna(inplace=True)

    return data_daily

def add_time_features(df):
    """
    Add time-based features day, weekday, month extracted from the index.
    """
    df['day'] = df.index.day
    df['weekday'] = df.index.weekday
    df['month'] = df.index.month
    return df

def add_cyclic_features(df):
    """
    Add cyclic sine and cosine representations for weekday, and month.
    """
    # Cyclic features for weekday
    df['weekday_sin'] = np.sin(2 * np.pi * df['weekday'] / 7)
    df['weekday_cos'] = np.cos(2 * np.pi * df['weekday'] / 7)
    # Cyclic features for month
    df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
    df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)
    return df

def create_final_dataset(data_daily, feature_columns, target_column):
    """
    Create the final dataset containing selected features and the target.
    """
    return data_daily[feature_columns + [target_column]]

def split_dataset(data, train_end_date, test_start_date, test_end_date):
    """
    Split the dataset into training and testing sets based on specified date ranges.
    """
    train_data = data[:train_end_date]
    test_data = data[test_start_date:test_end_date]
    return train_data, test_data

def scale_data(train_data, test_data):
    """
    Scale the training and testing data using MinMaxScaler.
    """
    scaler = MinMaxScaler()
    train_scaled = scaler.fit_transform(train_data)
    test_scaled = scaler.transform(test_data)
    return train_scaled, test_scaled, scaler

def create_sequences_multi_step(data, seq_length, horizon):
    """
    Create input sequences and corresponding multi-step target sequences.
    """
    X, y = [], []
    # Create samples only until there are enough steps for the forecast horizon
    for i in range(len(data) - seq_length - horizon + 1):
        X.append(data[i:i+seq_length, :-1])
        y.append(data[i+seq_length:i+seq_length+horizon, -1])
    return np.array(X), np.array(y)


