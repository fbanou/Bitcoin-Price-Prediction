import numpy as np
import time
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error

def recursive_forecast(model, last_window, steps):
    """
    Performs recursive forecasting using the trained model.

    Starting with the last available window from the training set, the function
    makes a prediction, appends the prediction to the input sequence shifting it,
    and repeats for the specified number of steps.
    """
    forecast = []
    input_seq = last_window.copy()

    for _ in range(steps):
        # Reshape the input sequence for prediction
        input_seq_reshaped = input_seq.reshape(1, input_seq.shape[0], input_seq.shape[1])
        # Make prediction
        pred = model.predict(input_seq_reshaped, verbose=0)[0, 0]
        forecast.append(pred)
        # Update the input sequence: remove the first value and append the new prediction
        input_seq = np.append(input_seq[1:], [[pred]], axis=0)
    return np.array(forecast)


def predict_and_evaluate_model(model, X_train, y_test, scaler, history):
    """
    Uses the last training window to perform recursive forecasting, inverse-transforms
    the predictions and test targets, computes evaluation metrics, prints them,
    and plots the forecast and loss curves.
    """
    # Use the last training window for recursive forecasting
    last_window = X_train[-1]
    forecast_steps = len(y_test)
    predictions = recursive_forecast(model, last_window, steps=forecast_steps)

    # Inverse transform predictions and true test values
    predictions_rescaled = scaler.inverse_transform(predictions.reshape(-1, 1))
    y_test_rescaled = scaler.inverse_transform(y_test.reshape(-1, 1))

    # Compute evaluation metrics
    mae = mean_absolute_error(y_test_rescaled, predictions_rescaled)
    mse = mean_squared_error(y_test_rescaled, predictions_rescaled)
    rmse = np.sqrt(mse)

    print("Mean Absolute Error (MAE):", mae)
    print("Mean Squared Error (MSE):", mse)
    print("Root Mean Squared Error (RMSE):", rmse)
    # Plot forecast and loss curves
    plot_forecast(y_test_rescaled, predictions_rescaled, title="Forecast vs True Prices (Single Experiment)")
    plot_loss_curve(history, title="Loss vs Validation Loss (Single Experiment)")

    return mae, rmse, predictions_rescaled, y_test_rescaled

def plot_loss_curve(history, title="Loss vs Validation Loss"):
    """
    Plots the training and validation loss curves.
    """
    plt.figure(figsize=(10,5))
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.title(title)
    plt.legend()
    plt.show()

def plot_forecast(y_true, y_pred, title="Bitcoin Price Prediction (Test Set)"):
    """
    Plots the true vs. predicted Bitcoin prices.
    """
    plt.figure(figsize=(12,6))
    plt.plot(y_true, label='True Prices', color='blue')
    plt.plot(y_pred, label='Predicted Prices', color='orange')
    plt.title(title)
    plt.xlabel('Time Steps')
    plt.ylabel('Bitcoin Price')
    plt.legend()
    plt.show()

def run_multiple_experiments(num_runs, train_data, test_data, scaler, time_step=100):
    """
    Runs the complete experiment multiple times num_runs using preprocessed data
    train_data and test_data to avoid reprocessing.
    Averages the evaluation metrics MAE, MSE, RMSE and predictions across runs,
    and plots the average forecast and loss curves.
    """
    mae_list = []
    mse_list = []
    rmse_list = []
    predictions_list = []
    histories = []
    train_times = []         # To store execution times for model training
    predict_times = []      # To store execution times for predict

    y_test_rescaled = None  # Will be updated from the last run

    for run in range(num_runs):
        print(f"Run {run+1}/{num_runs}")
        # Create sliding windows from training set
        from data_loader import create_dataset 
        X_train, y_train = create_dataset(train_data, time_step)
        X_train = X_train.reshape(X_train.shape[0], X_train.shape[1], X_train.shape[2])

        # For the test targets, take the last training target to the test series
        last_y_train = y_train[-1]
        y_test = test_data.iloc[:, 0].values
        y_test = np.insert(y_test, 0, last_y_train)

        num_features = X_train.shape[2]
        from model_training import build_model, train_model
        model = build_model(time_step, num_features)
        start_time = time.time()
        history = train_model(model, X_train, y_train)
        train_time = time.time() - start_time
        train_times.append(train_time)

        # Perform recursive forecasting
        start_time = time.time()
        from inference import recursive_forecast 
        predictions = recursive_forecast(model, X_train[-1], steps=len(y_test))
        predict_time = time.time() - start_time
        predict_times.append(predict_time)

        # Inverse transform predictions and true test values
        predictions_rescaled = scaler.inverse_transform(predictions.reshape(-1, 1))
        y_test_res = scaler.inverse_transform(y_test.reshape(-1, 1))

        # Compute evaluation metrics
        mae = mean_absolute_error(y_test_res, predictions_rescaled)
        mse = mean_squared_error(y_test_res, predictions_rescaled)
        rmse = np.sqrt(mse)

        mae_list.append(mae)
        mse_list.append(mse)
        rmse_list.append(rmse)
        predictions_list.append(predictions_rescaled)
        histories.append(history)
        y_test_rescaled = y_test_res

        print(f"Run {run+1} - MAE: {mae:.4f}, MSE: {mse:.4f}, RMSE: {rmse:.4f}")

    # Compute average metrics over all runs
    avg_mae = np.mean(mae_list)
    avg_mse = np.mean(mse_list)
    avg_rmse = np.mean(rmse_list)
    print(f"\nAverage MAE over {num_runs} runs: {avg_mae:.4f}")
    print(f"Average MSE over {num_runs} runs: {avg_mse:.4f}")
    print(f"Average RMSE over {num_runs} runs: {avg_rmse:.4f}")

    # Compute and print average execution times
    avg_train_time = np.mean(train_times)
    avg_predict_time = np.mean(predict_times)
    print(f"\nAverage Execution Times over {num_runs} Runs:")
    print(f"Model Training Time: {avg_train_time:.4f} seconds")
    print(f"Predicting Time: {avg_predict_time:.4f} seconds")

    # Average predictions across runs
    avg_predictions = np.mean(np.array(predictions_list), axis=0)
    plot_forecast(y_test_rescaled, avg_predictions, title="Average Forecast vs True Prices (Multiple Runs)")

    # Average loss curves over runs using the minimum number of epochs across runs
    min_epochs = min(len(h.history['loss']) for h in histories)
    avg_loss = np.mean([h.history['loss'][:min_epochs] for h in histories], axis=0)
    avg_val_loss = np.mean([h.history['val_loss'][:min_epochs] for h in histories], axis=0)

    plt.figure(figsize=(10,5))
    epochs_range = range(1, min_epochs+1)
    plt.plot(epochs_range, avg_loss, label="Average Training Loss")
    plt.plot(epochs_range, avg_val_loss, label="Average Validation Loss")
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title(f"Average Loss Curves over {num_runs} Runs")
    plt.legend()
    plt.show()
