import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

def load_dataset(file_path):
    """
    Load the dataset from the given CSV file, convert the 'unix' timestamp
    to datetime, set it as the index, and sort in ascending order.
    """
    data = pd.read_csv(file_path)
    data['date'] = pd.to_datetime(data['unix'], unit='s')
    data.set_index('date', inplace=True)
    data = data.sort_index(ascending=True)
    return data

def resample_data(data):
    """
    Select only numeric columns and resample the dataset to hourly frequency
    using the mean of the values.
    """
    numeric_data = data.select_dtypes(include=['float64', 'int64'])
    data_hourly = numeric_data.resample('1h').mean()
    return data_hourly

def add_time_features(df):
    """
    Create time-based features: hour, day, weekday, month, year,
    and a binary flag indicating if the day is a weekend.
    """
    df['hour'] = df.index.hour
    df['day'] = df.index.day
    df['weekday'] = df.index.weekday
    df['month'] = df.index.month
    df['year'] = df.index.year
    df['is_weekend'] = df['weekday'].apply(lambda x: 1 if x >= 5 else 0)
    return df

def add_cyclic_features(df):
    """
    Add cyclic sine and cosine representations for hour, weekday, and month.
    """
    df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
    df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
    df['weekday_sin'] = np.sin(2 * np.pi * df['weekday'] / 7)
    df['weekday_cos'] = np.cos(2 * np.pi * df['weekday'] / 7)
    df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
    df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)
    return df

def select_final_features(df):
    """
    Select and reorder the columns to be used in further processing.
    """
    # Drop any rows with missing values
    df = df[['hour', 'weekday', 'month', 'hour_sin', 'hour_cos',
             'weekday_sin', 'weekday_cos', 'month_sin', 'month_cos',
             'year', 'is_weekend', 'close']].dropna()
    return df

def add_seasonal_stats_from_train(df, train_df, group_col, target_col):
    """
    Compute the mean of the target variable for each group based on group_col
    using only the training set, and map these values to the full dataset.
    """
    # Calculate group means from the training data
    train_seasonal_mean = train_df.groupby(group_col)[target_col].mean()
    # Map the calculated means to a new column in the full dataset
    df[f'{group_col}_mean_{target_col}'] = df[group_col].map(train_seasonal_mean)
    return df

def split_data(df, train_end_date, test_start_date, test_end_date):
    """
    Split the dataset into training and testing sets based on provided date ranges.
    """
    train_data = df[:train_end_date]
    test_data = df[test_start_date:test_end_date]
    return train_data, test_data

def scale_data(train_data, test_data):
    """
    Scale the training and testing data using MinMaxScaler.
    Returns scaled DataFrames preserving the original indices and column names.
    """
    scaler = MinMaxScaler(feature_range=(0, 1))
    train_scaled = scaler.fit_transform(train_data)
    test_scaled = scaler.transform(test_data)

    # Convert back to DataFrame with original indices and column names
    train_scaled = pd.DataFrame(train_scaled, columns=train_data.columns, index=train_data.index)
    test_scaled = pd.DataFrame(test_scaled, columns=test_data.columns, index=test_data.index)
    return train_scaled, test_scaled, scaler


def create_windows(data, window_size, target_column_index):
    """
    Create sliding windows for features and target.
    """
    X, y = [], []
    for i in range(len(data) - window_size):
        # Use all columns except the target column as features
        X.append(data[i:i + window_size, :-1])
        # Target is the value in the target column immediately after the window
        y.append(data[i + window_size, target_column_index])
    return np.array(X), np.array(y)

def preprocess_data(file_path):

    data = load_dataset(file_path)
    data_hourly = resample_data(data)
    data_hourly = add_time_features(data_hourly)
    data_hourly = add_cyclic_features(data_hourly)
    data_hourly = select_final_features(data_hourly)
    return data_hourly
