import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

def load_data(file_path):
    """Loads the dataset from the given file path."""
    data = pd.read_csv(file_path)
    data['date'] = pd.to_datetime(data['unix'], unit='s')
    data.set_index('date', inplace=True)
    data = data.sort_index(ascending=True)
    return data

def resample_data(data, time):
    """Resamples the data based on the specified time interval."""
    numeric_data = data.select_dtypes(include=['float64', 'int64'])
    
    if time == 0:
        return numeric_data  # Minute-level data
    elif time == 1:
        return numeric_data.resample('1h').mean()  # Hourly data
    elif time == 2:
        return numeric_data.resample('1d').mean()  # Daily data
    else:
        raise ValueError("Invalid 'time' value. Choose 0 (minute), 1 (hourly), or 2 (daily).")

def scale_and_split_data(data, train_end_date, test_start_date, test_end_date):
    """Scales and splits the dataset into train and test sets."""
    data = data[['close']].dropna()

    train_data = data[:train_end_date]
    test_data = data[test_start_date:test_end_date]

    scaler = MinMaxScaler(feature_range=(0, 1))
    train_scaled = scaler.fit_transform(train_data)
    test_scaled = scaler.transform(test_data)

    train_scaled = pd.DataFrame(train_scaled, index=train_data.index, columns=train_data.columns)
    test_scaled = pd.DataFrame(test_scaled, index=test_data.index, columns=test_data.columns)

    return train_scaled, test_scaled, scaler

def create_dataset(data, time_step, forecast_horizon):
    """Creates sliding windows for input (X) and corresponding multi-step targets (y)."""
    X, y = [], []
    for i in range(len(data) - time_step - forecast_horizon + 1):
        X.append(data.iloc[i:i + time_step].values)
        y.append(data.iloc[i + time_step:i + time_step + forecast_horizon, 0].values)

    return np.array(X), np.array(y)
