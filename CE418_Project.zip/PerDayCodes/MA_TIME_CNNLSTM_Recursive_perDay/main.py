import pandas as pd
import numpy as np
from data_loader import load_and_preprocess_data, split_data, scale_data, create_sequences
from model_training import build_cnn_lstm_model, train_model
from inference import plot_training_history, plot_predictions, evaluate_predictions, predict_test, run_multiple_experiments

def main():
    # File path for the dataset
    file_path = "../../bitcoin-dataset.csv"

    # Load and preprocess the dataset
    data_daily = load_and_preprocess_data(file_path)

    # Define date ranges for training and testing
    train_end_date = '2022-02-18 23:59:59'
    test_start_date = '2022-02-19 00:00:00'
    test_end_date = '2022-02-28 23:59:59'

    # Define the feature columns and the target column
    feature_columns = ['MA_5', 'MA_24',
                       'weekday_sin', 'weekday_cos', 'month_sin', 'month_cos']
    target_column = 'close'

    # Split the data into training and testing sets
    train_data, test_data = split_data(data_daily, train_end_date, test_start_date, test_end_date,
                                       feature_columns, target_column)

    # Scale the data
    train_scaled, test_scaled, scaler = scale_data(train_data, test_data)

    # Create sequences for training
    sequence_length = 14
    x_train, y_train = create_sequences(train_scaled[:, :-1], train_scaled[:, -1], sequence_length)
    print("x_train shape:", x_train.shape)

    # Build and train the model (CNN + LSTM)
    model_lstm = build_cnn_lstm_model(sequence_length, len(feature_columns))
    print("\nRunning Single Experiment...")
    history = train_model(model_lstm, x_train, y_train)

    # Plot training history
    plot_training_history(history)

    # Generate predictions on the test set using the trained model
    predicted_close_unscaled, _ = predict_test(model_lstm, train_scaled, test_scaled,
                                               sequence_length, feature_columns, scaler, test_data)

    # Retrieve the actual close prices from the test data
    actual_close = test_data['close'].values

    # Plot the actual vs predicted close prices
    plot_predictions(test_data, actual_close, predicted_close_unscaled)

    # Evaluate the predictions using standard metrics
    evaluate_predictions(actual_close, predicted_close_unscaled)

    # Run the experiment 10 times and plot/print the averaged results
    print("\nRunning multiple experiments...")
    run_multiple_experiments(x_train, y_train, train_scaled, test_scaled, sequence_length,
                             feature_columns, scaler, test_data, num_runs=10)

if __name__ == "__main__":
    main()
