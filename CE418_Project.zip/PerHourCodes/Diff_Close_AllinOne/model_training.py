import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping

def train_model_custom(X_train, y_train, epochs=100, patience=15, learning_rate=0.001):
    """
    Builds and trains a LSTM model for multi-step forecasting.
    Performs an internal train-validation split.
    """
    model = Sequential([
        LSTM(128, return_sequences=True, input_shape=(X_train.shape[1], X_train.shape[2])),
        LSTM(64, return_sequences=True),
        LSTM(32),
        Dense(32, activation='relu'),
        Dense(y_train.shape[1])  # Number of forecast steps
    ])
    model.compile(optimizer=Adam(learning_rate=learning_rate), loss='mse', metrics=['mae'])
    early_stopping = EarlyStopping(monitor='val_loss', patience=patience, restore_best_weights=True)
    history = model.fit(X_train, y_train, validation_split=0.2, epochs=epochs,
                        batch_size=128, verbose=1, callbacks=[early_stopping], shuffle=False)
    print("Model training complete!")
    return model, history
