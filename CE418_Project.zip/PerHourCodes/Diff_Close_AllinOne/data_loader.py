import pandas as pd
import numpy as np
import time
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler

"""### Data Loading and Preprocessing Functions"""

def load_data(file_path):
    """
    Loads the CSV file, converts UNIX timestamps to datetime,
    sets the datetime as the index, and sorts the data in ascending order.
    """
    data = pd.read_csv(file_path)
    data['date'] = pd.to_datetime(data['unix'], unit='s')
    data.set_index('date', inplace=True)
    data = data.sort_index(ascending=True)
    return data

def resample_data(data, sampling_type):
    """
    Resamples the data based on the sampling_type.

    Args:
        sampling_type int:
            0 -> minute sampling,
            1 -> hourly sampling,
            2 -> daily sampling,
            3 -> monthly sampling.

    Returns:
        DataFrame with only the 'close' column.
    """
    numeric_data = data.select_dtypes(include=['float64', 'int64'])
    if sampling_type == 0:
        print("> Minute Sampling!")
        data_resampled = numeric_data
    elif sampling_type == 1:
        print("> Hourly Sampling!")
        data_resampled = numeric_data.resample('1h').mean()
    elif sampling_type == 2:
        print("> Daily Sampling!")
        data_resampled = numeric_data.resample('1d').mean()
    elif sampling_type == 3:
        print("> Monthly Sampling!")
        data_resampled = numeric_data.resample('1m').mean()
    else:
        raise ValueError("Invalid sampling type. Choose 0, 1, 2, or 3.")
    data_resampled = data_resampled[['close']].dropna()
    return data_resampled

def split_data(data, train_end_date, test_start_date, test_end_date):
    """
    Splits the data into training and testing sets using given date ranges.
    """
    train_data = data[:train_end_date]
    test_data = data[test_start_date:test_end_date]
    return train_data, test_data

def scale_dataset(train_data):
    """
    Scales the training and test sets using MinMaxScaler.
    Returns scaled DataFrames with original indices and columns and the scaler.
    """
    scaler = MinMaxScaler(feature_range=(0, 1))
    train_scaled = scaler.fit_transform(train_data)
    train_scaled = pd.DataFrame(train_scaled, index=train_data.index, columns=train_data.columns)
    return train_scaled, scaler

def create_dataset(data, time_step, forecast_horizon):
    """
    Creates sliding windows sequences and corresponding multi-step targets.

    For each window of length time_step, the target is the next forecast_horizon values.
    """
    X, y = [], []
    for i in range(len(data) - time_step - forecast_horizon + 1):
        X.append(data.iloc[i:i+time_step].values)
        y.append(data.iloc[i+time_step:i+time_step+forecast_horizon, 0].values)
    return np.array(X), np.array(y)
