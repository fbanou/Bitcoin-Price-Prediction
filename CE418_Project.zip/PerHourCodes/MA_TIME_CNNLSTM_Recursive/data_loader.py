import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

def add_time_features(df):
    """
    Add time-based features to the DataFrame.
    Features include hour, day, weekday, month, and a weekend indicator.
    """
    df['hour'] = df.index.hour
    df['day'] = df.index.day
    df['weekday'] = df.index.weekday
    df['month'] = df.index.month
    df['is_weekend'] = df['weekday'].apply(lambda x: 1 if x >= 5 else 0)
    return df

def add_cyclic_features(df):
    """
    Add cyclic sine and cosine representations for time-related features:
    hour, weekday, and month.
    """
    # Cyclic features for hour
    df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
    df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
    # Cyclic features for weekday
    df['weekday_sin'] = np.sin(2 * np.pi * df['weekday'] / 7)
    df['weekday_cos'] = np.cos(2 * np.pi * df['weekday'] / 7)
    # Cyclic features for month
    df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
    df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)
    return df

def load_and_preprocess_data(file_path):
    """
    Load CSV data, convert the unix timestamp to datetime, resample to hourly frequency,
    add time-based and cyclic features, compute moving averages, and drop NaN values.
    """
    # Load the CSV data
    data = pd.read_csv(file_path)

    # Convert unix timestamp to datetime and set it as the index
    data['date'] = pd.to_datetime(data['unix'], unit='s')
    data.set_index('date', inplace=True)
    data = data.sort_index(ascending=True)

    # Keep only numeric columns
    numeric_data = data.select_dtypes(include=['float64', 'int64'])

    # Resample data to hourly frequency, mean values
    data_hourly = numeric_data.resample('1h').mean()

    # Add time-based features and cyclic representations
    data_hourly = add_time_features(data_hourly)
    data_hourly = add_cyclic_features(data_hourly)

    # Compute moving averages, MA_24 and MA_240
    data_hourly['MA_24'] = data_hourly['close'].rolling(window=24).mean()
    data_hourly['MA_240'] = data_hourly['close'].rolling(window=240).mean()

    # Drop rows with missing values
    data_hourly.dropna(inplace=True)
    return data_hourly

def split_data(data, train_end_date, test_start_date, test_end_date, feature_columns, target_column):
    """
    Split the data into training and testing sets based on the specified date ranges.
    Only the selected feature columns and target column are retained.
    """
    train_data = data[:train_end_date]
    test_data = data[test_start_date:test_end_date]
    train_data = train_data[feature_columns + [target_column]]
    test_data = test_data[feature_columns + [target_column]]
    return train_data, test_data

def scale_data(train_data, test_data):
    """
    Scale the training and testing data using MinMaxScaler.
    """
    scaler = MinMaxScaler()
    train_scaled = scaler.fit_transform(train_data)
    test_scaled = scaler.transform(test_data)
    return train_scaled, test_scaled, scaler

def create_sequences(features, target, sequence_length):
    """
    Create sequences of features and corresponding targets for time series forecasting.
    Each sequence is of length 'sequence_length', and the target is the value following the sequence.
    """
    x, y = [], []
    for i in range(len(features) - sequence_length):
        x.append(features[i:i + sequence_length])
        y.append(target[i + sequence_length])
    return np.array(x), np.array(y)
