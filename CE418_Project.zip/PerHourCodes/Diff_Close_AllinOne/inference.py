import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, mean_absolute_error
import time


def forecast_model(model, last_window):
    """
    Uses the trained model to forecast based on the last input window.
    """
    input_seq = last_window.reshape(1, last_window.shape[0], last_window.shape[1])
    predictions = model.predict(input_seq, verbose=1)
    return predictions[0]

def reconstruct_forecast(predictions, last_close_value):
    """
    Reconstructs the original close forecast from the predicted differences.
    """

    forecast_original = [last_close_value + predictions[0]]
    for i in range(1, len(predictions)):
        forecast_original.append(forecast_original[i-1] + predictions[i])
    return np.array(forecast_original).reshape(-1, 1)


def compute_metrics(y_true, y_pred):
    """
    Computes evaluation metrics: MAE, MSE, RMSE
    """
    mae = mean_absolute_error(y_true, y_pred)
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    return mae, mse, rmse

def plot_forecast_results(y_true, y_pred, title="Forecast vs True Prices"):
    """
    Plots the true and predicted prices.
    """
    plt.figure(figsize=(12,6))
    plt.plot(y_true, label="True Prices", color="blue")
    plt.plot(y_pred, label="Predicted Prices", color="orange")
    plt.title(title)
    plt.xlabel("Time Steps")
    plt.ylabel("Bitcoin Price")
    plt.legend()
    plt.show()

def plot_loss_history(history, title="Loss vs Validation Loss"):
    """
    Plots the training and validation loss curves.
    """
    plt.figure(figsize=(10,5))
    plt.plot(history.history['loss'], label="Training Loss")
    plt.plot(history.history['val_loss'], label="Validation Loss")
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title(title)
    plt.legend()
    plt.show()


def predict_and_evaluate_model(model, X_train, y_test, scaler, history, last_close_value):
    """
    Uses the last training window to forecast the differences, reconstructs the
    forecast of close values, inverse-transforms predictions and true values,
    computes and prints evaluation metrics, and plots the forecast and loss curves.
    """
    # Forecast differences using the last training window
    forecast_differences_scaled = forecast_model(model, X_train[-1])
    forecast_differences = scaler.inverse_transform(forecast_differences_scaled.reshape(-1,1))

    # Reconstruct forecast using the last training close value
    forecast_close = reconstruct_forecast(forecast_differences, last_close_value)

    mae, mse, rmse = compute_metrics(y_test, forecast_close)
    print("Single Experiment Results:")
    print(f"MAE: {mae:.4f}")
    print(f"MSE: {mse:.4f}")
    print(f"RMSE: {rmse:.4f}")

    plot_forecast_results(y_test, forecast_close, title="Forecast vs True Prices (Single Experiment)")
    plot_loss_history(history, title="Loss vs Validation Loss (Single Experiment)")

    return mae, rmse, forecast_close, y_test


def run_multiple_experiments1(num_runs, X_train, y_train, y_test, scaler, last_close_value):
    """
    Run the training and evaluation multiple times num_runs and compute average metrics,
    average forecast, and average loss curves.
    """
    mae_list = []
    rmse_list = []
    predictions_list = []
    histories_list = []
    train_times = []         # To store execution times for model training
    predict_times = []      # To store execution times for predict

    for run in range(num_runs):
        print(f"\nRun {run+1}/{num_runs}")
        # Train the model
        start_time = time.time()
        from model_training import train_model_custom
        model, history = train_model_custom(X_train, y_train)
        train_time = time.time() - start_time
        train_times.append(train_time)

        # Evaluate the model
        start_time = time.time()
        mae, rmse, forecast_close, y_test_eval = predict_and_evaluate_model(model, X_train, y_test, scaler, history, last_close_value)
        predict_time = time.time() - start_time
        predict_times.append(predict_time)
        
        mae_list.append(mae)
        rmse_list.append(rmse)
        predictions_list.append(forecast_close)
        histories_list.append(history)
    
    # Compute average metrics
    avg_mae = np.mean(mae_list)
    avg_rmse = np.mean(rmse_list)
    print("\nAverage Evaluation Metrics over {} Runs:".format(num_runs))
    print(f"Average MAE: {avg_mae:.4f}")
    print(f"Average RMSE: {avg_rmse:.4f}")

    # Compute and print average execution times
    avg_train_time = np.mean(train_times)
    avg_predict_time = np.mean(predict_times)
    print(f"\nAverage Execution Times over {num_runs} Runs:")
    print(f"Model Training Time: {avg_train_time:.4f} seconds")
    print(f"Predicting Time: {avg_predict_time:.4f} seconds")

    # Compute average forecast (averaging predictions across runs)
    avg_forecast = np.mean(np.array(predictions_list), axis=0)
    plot_forecast_results(y_test_eval, avg_forecast, title="Average Forecast vs True Prices (Multiple Runs)")

    # Compute average loss curves
    min_epochs = min(len(h.history['loss']) for h in histories_list)
    avg_loss = np.mean([h.history['loss'][:min_epochs] for h in histories_list], axis=0)
    avg_val_loss = np.mean([h.history['val_loss'][:min_epochs] for h in histories_list], axis=0)
    
    plt.figure(figsize=(10,5))
    epochs_range = range(1, min_epochs+1)
    plt.plot(epochs_range, avg_loss, label="Average Training Loss")
    plt.plot(epochs_range, avg_val_loss, label="Average Validation Loss")
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title(f"Average Loss Curves over {num_runs} Runs")
    plt.legend()
    plt.show()
