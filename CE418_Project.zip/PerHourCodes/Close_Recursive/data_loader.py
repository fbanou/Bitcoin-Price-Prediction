import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

def load_and_preprocess(file_path):
    """
    Loads the dataset, converts UNIX timestamps to datetime, sorts the data,
    selects the 'close' column, resamples it hourly, and drops missing values.
    Returns a DataFrame with the 'close' values.
    """
    data = pd.read_csv(file_path)
    data['date'] = pd.to_datetime(data['unix'], unit='s')  # Convert UNIX to datetime
    data.set_index('date', inplace=True)
    data = data.sort_index(ascending=True)  # Sort in ascending order

    # Select only numeric columns and then choose the 'close' column
    numeric_data = data.select_dtypes(include=['float64', 'int64'])
    data_hourly = numeric_data.resample('1h').mean()
    data_hourly = data_hourly[['close']].dropna()
    return data_hourly

def scale_data(df):
    """
    Scales the DataFrame with column 'close' using MinMaxScaler.
    Returns the scaled data as a DataFrame preserving the original index and column names
    and the scaler object.
    """
    scaler = MinMaxScaler(feature_range=(0, 1))
    data_scaled = scaler.fit_transform(df)
    data_scaled_df = pd.DataFrame(data_scaled, columns=df.columns, index=df.index)
    return data_scaled_df, scaler

def split_train_test(df):
    """
    Splits the DataFrame into training and testing sets based on fixed date ranges.
    """
    train_end_date = '2022-02-18 23:59:59'  # End of train set
    test_start_date = '2022-02-19 00:00:00'  # Start of test set
    test_end_date = '2022-02-28 23:59:59'      # End of test set
    train_data = df[:train_end_date]
    test_data = df[test_start_date:test_end_date]
    return train_data, test_data, test_start_date, test_end_date

def create_dataset(data, time_step):
    """
    Creates sliding windows sequences and corresponding targets.

    For each window of length 'time_step', the target is the value of 'close'
    immediately following that window.
    """
    X, y = [], []
    for i in range(len(data) - time_step):
        X.append(data.iloc[i:i + time_step].values)
        y.append(data.iloc[i + time_step, 0])  # Target is the 'close' value
    return np.array(X), np.array(y)
