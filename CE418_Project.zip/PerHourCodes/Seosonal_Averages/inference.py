import matplotlib.pyplot as plt
import numpy as np
import time
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error

def predict_and_evaluate(model, X_test, y_test, scaler, data_columns, target_column, test_start_date, test_end_date):
    """
    Use the trained model to predict on the test set, then inverse-transform
    the scaled predictions and true values. Finally, compute and print evaluation metrics,
    and plot the real vs predicted close prices.
    """
    # Predict on test set
    y_pred = model.predict(X_test)

    # Determine the number of columns except the target to create dummy columns for inverse_transform
    n_features = len(data_columns) - 1

    y_test_unscaled = scaler.inverse_transform(
        np.c_[np.zeros((y_test.shape[0], n_features)), y_test]
    )[:, -1]

    y_pred_unscaled = scaler.inverse_transform(
        np.c_[np.zeros((y_pred.shape[0], n_features)), y_pred]
    )[:, -1]

    # Compute evaluation metrics
    mae = mean_absolute_error(y_test_unscaled, y_pred_unscaled)
    mse = mean_squared_error(y_test_unscaled, y_pred_unscaled)
    rmse = np.sqrt(mse)

    print("Mean Absolute Error (MAE):", mae)
    print("Mean Squared Error (MSE):", mse)
    print("Root Mean Squared Error (RMSE):", rmse)

    # Create a date range for plotting
    dates = pd.date_range(start=test_start_date, end=test_end_date, freq='h')[:len(y_test_unscaled)]

    # Plot actual vs predicted close prices
    plt.figure(figsize=(12, 6))
    plt.plot(dates, y_test_unscaled, label='Real Close Prices', alpha=0.75)
    plt.plot(dates, y_pred_unscaled, label='Predicted Close Prices', alpha=0.75)
    plt.xticks(rotation=45)
    plt.xlabel('Date')
    plt.ylabel('Close Price')
    plt.title('Real vs Predicted Close Prices')
    plt.legend()
    plt.grid(True)
    plt.show()


def plot_loss(history):
    """
    Plot the training and validation loss curves.
    """
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.title('Loss vs Validation Loss')
    plt.show()

def run_multiple_experiments(num_runs, X_train, y_train, X_test, y_test, scaler, data_columns, target_column, test_start_date, test_end_date):
    """
    Run the training and evaluation process multiple times num_runs, then average the evaluation
    metrics, loss curves, and predicted values.
    """
    training_histories = []
    mae_list = []
    rmse_list = []
    predictions = []
    train_times = []         # To store execution times for model training
    predict_times = []      # To store execution times for predict

    # Prepare the true values for evaluation by inverse transforming y_test
    n_features = len(data_columns) - 1
    y_test_unscaled = scaler.inverse_transform(
        np.c_[np.zeros((y_test.shape[0], n_features)), y_test.reshape(-1, 1)]
    )[:, -1]

    for run in range(num_runs):
        print(f"Run {run+1}/{num_runs}")
        from model_training import build_model, compile_and_train_model
        model = build_model(input_shape=(X_train.shape[1], X_train.shape[2]))

        start_time = time.time()
        history = compile_and_train_model(model, X_train, y_train)
        train_time = time.time() - start_time
        train_times.append(train_time)

        training_histories.append(history)

        start_time = time.time()
        y_pred = model.predict(X_test)
        predict_time = time.time() - start_time
        predict_times.append(predict_time)

        y_pred_unscaled = scaler.inverse_transform(
            np.c_[np.zeros((y_pred.shape[0], n_features)), y_pred]
        )[:, -1]
        predictions.append(y_pred_unscaled)

        mae = mean_absolute_error(y_test_unscaled, y_pred_unscaled)
        rmse = np.sqrt(mean_squared_error(y_test_unscaled, y_pred_unscaled))
        mae_list.append(mae)
        rmse_list.append(rmse)
        print(f"Run {run+1} - MAE: {mae}, RMSE: {rmse}")

    avg_mae = np.mean(mae_list)
    avg_rmse = np.mean(rmse_list)
    print(f"\nAverage MAE over {num_runs} runs: {avg_mae}")
    print(f"Average RMSE over {num_runs} runs: {avg_rmse}")

    # Compute and print average execution times
    avg_train_time = np.mean(train_times)
    avg_predict_time = np.mean(predict_times)
    print(f"\nAverage Execution Times over {num_runs} Runs:")
    print(f"Model Training Time: {avg_train_time:.4f} seconds")
    print(f"Predicting Time: {avg_predict_time:.4f} seconds")

    # Average predictions
    avg_predictions = np.mean(np.array(predictions), axis=0)

    dates = pd.date_range(start=test_start_date, end=test_end_date, freq='h')[:len(avg_predictions)]
    plt.figure(figsize=(12, 6))
    plt.plot(dates, y_test_unscaled, label="Real Close Prices", color='blue', linestyle='dashed')
    plt.plot(dates, avg_predictions, label="Average Predicted Close Prices", color='red')
    plt.xlabel("Date")
    plt.ylabel("Close Price")
    plt.title("Real vs Average Predicted Close Prices over Multiple Runs")
    plt.xticks(rotation=45)
    plt.legend()
    plt.grid(True)
    plt.show()

    # Average the loss curves over runs using the minimum epoch length across runs
    min_epochs = min(len(hist.history['loss']) for hist in training_histories)
    avg_loss = np.mean([hist.history['loss'][:min_epochs] for hist in training_histories], axis=0)
    avg_val_loss = np.mean([hist.history['val_loss'][:min_epochs] for hist in training_histories], axis=0)

    plt.figure(figsize=(10, 5))
    epochs_range = range(1, min_epochs+1)
    plt.plot(epochs_range, avg_loss, label="Average Training Loss")
    plt.plot(epochs_range, avg_val_loss, label="Average Validation Loss")
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title(f"Average Loss Curves over {num_runs} Runs")
    plt.legend()
    plt.show()
