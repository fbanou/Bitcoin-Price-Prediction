import time
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, BatchNormalization
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping

def build_model(time_step, num_features):
    """
    Builds and returns a Sequential LSTM model.

    The model consists of three LSTM layers with dropout and two Dense layers.
    """
    model = Sequential([
        LSTM(128, return_sequences=True, input_shape=(time_step, num_features)),
        Dropout(0.2),
        LSTM(64, return_sequences=True),
        Dropout(0.2),
        LSTM(32, return_sequences=False),
        Dropout(0.2),
        Dense(32, activation='relu'),
        Dense(1)  # Output layer for predicting 'close'
    ])
    return model

def train_model(model, X_train, y_train):
    """
    Compiles and trains the model using Adam optimizer and MSE loss.
    Uses early stopping to prevent overfitting.

    Returns the training history.
    """
    early_stopping = EarlyStopping(monitor='val_loss', patience=15, restore_best_weights=True)
    model.compile(optimizer=Adam(learning_rate=0.001), loss='mean_squared_error', metrics=['mean_absolute_error'])
    history = model.fit(X_train, y_train, batch_size=256, epochs=50, validation_split=0.2,
                        verbose=1, callbacks=[early_stopping], shuffle=False)
    return history
