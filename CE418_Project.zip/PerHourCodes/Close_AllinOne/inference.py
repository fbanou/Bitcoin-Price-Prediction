import time
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, mean_absolute_error

def forecast(model, last_window):
    """Generates forecasts using the trained model."""
    input_seq_reshaped = last_window.reshape(1, last_window.shape[0], 1)
    return model.predict(input_seq_reshaped, verbose=0)[0]

def predict_and_evaluate_model(model, X_test, y_test, scaler, dates):
    """Generates predictions, evaluates the model, and plots results."""
    predictions = forecast(model, X_test)

    predictions_rescaled = scaler.inverse_transform(predictions.reshape(-1, 1))
    y_test_rescaled = scaler.inverse_transform(y_test.reshape(-1, 1))

    mae = mean_absolute_error(y_test_rescaled, predictions_rescaled)
    mse = mean_squared_error(y_test_rescaled, predictions_rescaled)
    rmse = np.sqrt(mse)

    print(f"\nSingle Run Results")
    print(f"MAE: {mae:.4f}")
    print(f"MSE: {mse:.4f}")
    print(f"RMSE: {rmse:.4f}")

    plot_forecast(y_test_rescaled, predictions_rescaled, dates, title="Bitcoin Price Prediction (Single Run)")

def plot_forecast(y_true, y_pred, dates, title="Forecast vs True Prices"):
    """Plots actual vs predicted prices with correct date labels."""
    plt.figure(figsize=(12, 6))
    plt.plot(dates, y_true, label='True Prices', color='blue')
    plt.plot(dates, y_pred, label='Predicted Prices', color='orange')
    plt.title(title)
    plt.xlabel('Date')
    plt.ylabel('Bitcoin Price')
    plt.legend()
    plt.xticks(rotation=45)
    plt.grid(True)
    plt.show()

def plot_loss(history):
    """Plots training & validation loss curves."""
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title('Training and Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()

def run_multiple_experiments(num_runs, X_train, y_train, X_test, y_test, dates, scaler, batch_size, forecast_horizon):
    """Runs multiple experiments and averages the results."""
    mse_list, mae_list = [], []
    predictions_list, histories = [], []
    min_epochs = float('inf')
    train_times = []         # To store execution times for model training
    predict_times = []       # To store execution times for predict
    loss_list, val_loss_list = [], []

    for run in range(num_runs):
        print(f"Run {run+1}/{num_runs}")
        start_time = time.time()
        from model_training import train_model
        model, history = train_model(X_train, y_train, epochs=100, patience=15, batch_size=batch_size, forecast_horizon=forecast_horizon)
        train_time = time.time() - start_time
        train_times.append(train_time)

        min_epochs = min(min_epochs, len(history.history['loss']))
        histories.append(history)
        loss_list.append(history.history['loss'])
        val_loss_list.append(history.history['val_loss'])

        start_time = time.time()
        predictions = forecast(model, X_test)
        predict_time = time.time() - start_time
        predict_times.append(predict_time)

        predictions_rescaled = scaler.inverse_transform(predictions.reshape(-1, 1))
        y_test_rescaled = scaler.inverse_transform(y_test.reshape(-1, 1))

        mse_list.append(mean_squared_error(y_test_rescaled, predictions_rescaled))
        mae_list.append(mean_absolute_error(y_test_rescaled, predictions_rescaled))

        predictions_list.append(predictions_rescaled)

    avg_predictions = np.mean(np.array(predictions_list), axis=0)
    avg_mse = np.mean(mse_list)
    avg_mae = np.mean(mae_list)
    loss_array = np.array([l[:min_epochs] for l in loss_list])
    val_loss_array = np.array([v[:min_epochs] for v in val_loss_list])

    avg_loss = np.mean(loss_array, axis=0)
    avg_val_loss = np.mean(val_loss_array, axis=0)

    plt.figure(figsize=(10, 5))
    plt.plot(avg_loss, label="Average Training Loss")
    plt.plot(avg_val_loss, label="Average Validation Loss")
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title(f"Average Loss Curves over {num_runs} Runs")
    plt.legend()
    plt.show()

    plot_forecast(y_test_rescaled, avg_predictions, dates, title=f'Average Forecast ({num_runs} Runs)')

    print(f"\nAverage MSE: {avg_mse:.4f}, Average MAE: {avg_mae:.4f}")

    avg_train_time = np.mean(train_times)
    avg_predict_time = np.mean(predict_times)
    print(f"\nAverage Execution Times over {num_runs} Runs:")
    print(f"Model Training Time: {avg_train_time:.4f} seconds")
    print(f"Predicting Time: {avg_predict_time:.4f} seconds")
