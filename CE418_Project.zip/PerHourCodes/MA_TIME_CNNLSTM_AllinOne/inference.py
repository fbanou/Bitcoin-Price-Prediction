import numpy as np
import time
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error

def make_forecast(model, train_scaled, sequence_length, num_features, scaler, feature_columns, forecast_horizon):
    """
    Make a multi-step forecast using the last available sequence from the training data.

    The model outputs scaled predictions which are then converted back to the original scale
    using the scaler's inverse_transform.
    """
    # Prepare input sequence for prediction features only
    X_input = train_scaled[-sequence_length:, :-1].reshape(1, sequence_length, num_features)

    # Predict the multi-step forecast output shape: 1, forecast_horizon
    forecast_scaled = model.predict(X_input)
    forecast_scaled = forecast_scaled.flatten() 

    # Create a dummy array for the feature columns to use with the scaler's inverse_transform
    dummy = np.zeros((forecast_scaled.shape[0], len(feature_columns)))  

    # Concatenate dummy features with the forecast target values to create a complete vector
    forecast_concat = np.concatenate([dummy, forecast_scaled.reshape(-1, 1)], axis=1)  

    # Inverse transform to retrieve the forecast in the original scale, extract the target column
    forecast_unscaled = scaler.inverse_transform(forecast_concat)[:, -1]
    return forecast_unscaled

def plot_forecast(test_data, target_column, forecast_unscaled, forecast_horizon):
    """
    Plot the actual target values versus the predicted forecast.
    """
    test_index = test_data.index[:forecast_horizon]
    plt.figure(figsize=(12, 6))
    plt.plot(test_index, test_data[target_column].values[:forecast_horizon],
             label="Actual Close", color='blue', linestyle='dashed')
    plt.plot(test_index, forecast_unscaled, label="Predicted Close", color='red')
    plt.xlabel("Date")
    plt.ylabel("Close Price")
    plt.title("Actual vs Predicted Close Prices (Direct Multi-Step Forecasting)")
    plt.legend()
    plt.grid(True)
    plt.show()

def evaluate_forecast(actual, forecast):
    """
    Evaluate the forecast using common regression metrics and print the results.
    """
    mae = mean_absolute_error(actual, forecast)
    mse = mean_squared_error(actual, forecast)
    rmse = np.sqrt(mse)

    print("Mean Absolute Error (MAE):", mae)
    print("Mean Squared Error (MSE):", mse)
    print("Root Mean Squared Error (RMSE):", rmse)

def run_multiple_experiments_multi_step(num_runs, X_train, y_train, train_scaled, sequence_length,
                                        num_features, scaler, feature_columns, forecast_horizon,
                                        test_data, target_column):
    """
    Run the multi-step forecasting experiment multiple times num_runs,
    and average the training histories, forecasts, and evaluation metrics.
    """
    training_histories = []  # To store training histories for each run
    forecasts = []           # To store forecast predictions for each run
    metrics_list = []        # To store evaluation metrics for each run
    train_times = []         # To store execution times for model training
    forecast_times = []      # To store execution times for forecasting

    # Actual target values from test data for forecast_horizon
    actual = test_data[target_column].values[:forecast_horizon]

    for run in range(num_runs):
        print(f"Run {run+1}/{num_runs}")
        # Build the multi-step forecasting model
        from model_training import build_multi_step_model, train_model 
        model = build_multi_step_model(sequence_length, num_features, forecast_horizon)

        # Train the model
        start_time = time.time()
        history = train_model(model, X_train, y_train)
        train_time = time.time() - start_time
        train_times.append(train_time)

        training_histories.append(history)
        # Make forecast using the last sequence from the training data
        start_time = time.time()
        forecast_unscaled = make_forecast(model, train_scaled, sequence_length, num_features, scaler, feature_columns, forecast_horizon)
        forecast_time = time.time() - start_time
        forecast_times.append(forecast_time)

        forecasts.append(forecast_unscaled)
        # Compute evaluation metrics for this run
        from sklearn.metrics import mean_absolute_error, mean_squared_error
        mae = mean_absolute_error(actual, forecast_unscaled)
        mse = mean_squared_error(actual, forecast_unscaled)
        rmse = np.sqrt(mse)
        metrics_list.append({'MAE': mae, 'MSE': mse, 'RMSE': rmse})

    # Determine the minimum number of epochs across runs due to early stopping
    min_epochs = min(len(hist.history['loss']) for hist in training_histories)
    # Average the training and validation loss curves over the minimum number of epochs
    avg_loss = np.mean([hist.history['loss'][:min_epochs] for hist in training_histories], axis=0)
    avg_val_loss = np.mean([hist.history['val_loss'][:min_epochs] for hist in training_histories], axis=0)

    # Plot average training history
    plt.figure(figsize=(10, 5))
    epochs_range = range(1, min_epochs+1)
    plt.plot(epochs_range, avg_loss, label='Average Training Loss')
    plt.plot(epochs_range, avg_val_loss, label='Average Validation Loss')
    plt.xlabel("Epochs")
    plt.ylabel("Loss (MSE)")
    plt.title(f"Average Loss Evolution over {num_runs} Runs")
    plt.legend()
    plt.show()

    # Average the forecast predictions
    avg_forecast = np.mean(np.array(forecasts), axis=0)

    # Plot actual vs. average forecast
    test_index = test_data.index[:forecast_horizon]
    plt.figure(figsize=(12, 6))
    plt.plot(test_index, actual, label="Actual Close", color='blue', linestyle='dashed')
    plt.plot(test_index, avg_forecast, label="Average Predicted Close", color='red')
    plt.xlabel("Date")
    plt.ylabel("Close Price")
    plt.title("Actual vs Average Predicted Close Prices (Multi-Step Forecasting)")
    plt.legend()
    plt.grid(True)
    plt.show()

    # Average evaluation metrics over all runs
    avg_metrics = {
         'MAE': np.mean([m['MAE'] for m in metrics_list]),
         'MSE': np.mean([m['MSE'] for m in metrics_list]),
         'RMSE': np.mean([m['RMSE'] for m in metrics_list]),
    }
    print(f"Average Metrics over {num_runs} Runs:")
    print("Mean Absolute Error (MAE):", avg_metrics['MAE'])
    print("Mean Squared Error (MSE):", avg_metrics['MSE'])
    print("Root Mean Squared Error (RMSE):", avg_metrics['RMSE'])

    # Compute and print average execution times
    avg_train_time = np.mean(train_times)
    avg_forecast_time = np.mean(forecast_times)
    print(f"\nAverage Execution Times over {num_runs} Runs:")
    print(f"Model Training Time: {avg_train_time:.4f} seconds")
    print(f"Forecasting Time: {avg_forecast_time:.4f} seconds")
